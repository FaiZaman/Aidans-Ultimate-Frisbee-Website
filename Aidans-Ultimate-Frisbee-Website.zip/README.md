# Aidan's-Ultimate-Frisbee-Website
Coursework for Web Programming.
May use as actual frisbee website when completed

Using the original test cases for testing - passes all of these
POST request for adding people adds to JSON at /people and then calls GET request on /people to refresh table contents

Cloud deployment link: https://st-aidans-ultimate-frisbee.herokuapp.com/